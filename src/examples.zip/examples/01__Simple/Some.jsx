const Some = () => <div>Всем, привет!</div>;

// ----------------------------------------
// usage
export const App = () => {
    return <Some />;
}
