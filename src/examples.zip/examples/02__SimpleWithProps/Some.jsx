// props
const Some = ({ title }) => <div>{title}</div>;

// ----------------------------------------
// usage
export const App = () => {
    return <Some title="Здравствуйте!"/>;
}
